  //464 Создание элементов из массива
/*
№1

Модифицируйте мой код так, чтобы по клику на абзац к его содержимому прибавлялась единица.
*/
// let arr = [1, 2, 3, 4, 5];
// let parent = document.querySelector('#parent');

// for (let elem of arr) {
// 	let p = document.createElement('p');
// 	p.textContent = elem;
// 	p.addEventListener("click", function(){
//         p.textContent+="1"
//     })
// 	parent.appendChild(p);
// }


//465 Практика на создание списков ul
/*
№1

Дан ul:

<ul id="elem"></ul>
Дан массив. Вставьте элементы этого массива в конец ul так, чтобы каждый элемент стоял в своем li.
*/
// let arr = [1, 2, 3, 4, 5];
// let elem_ul=document.querySelector("#elem");
// for (let elem of arr){
//     let li = document.createElement("li");
//     li.textContent = elem;
//     elem_ul.appendChild(li)
// }

/*
№2

Модифицируйте предыдущую задачу так, чтобы по клику на любой из вставленных элементов на экран выводился текст этого элемента.
*/
// let arr = [1, 2, 3, 4, 5];
// let elem_ul=document.querySelector("#elem");
// for (let elem of arr){
//     let li = document.createElement("li");
//     li.textContent = elem;
//     li.addEventListener("click", function(){
//         alert(li.textContent)
//     })
//     elem_ul.appendChild(li)
// }

/*
№3

Модифицируйте предыдущую задачу так, чтобы по клику на li ей в конец добавлялся '!'.
*/
// let arr = [1, 2, 3, 4, 5];
// let elem_ul=document.querySelector("#elem");
// for (let elem of arr){
//     let li = document.createElement("li");
//     li.textContent = elem;
//     li.addEventListener("click", function(){
//         li.textContent+="!"
//     })
//     elem_ul.appendChild(li)
// }

/*
№4

Модифицируйте предыдущую задачу так, чтобы по повторное нажатие на li не приводило к добавлению второго '!'.
*/
// let arr = [1, 2, 3, 4, 5];
// let elem_ul=document.querySelector("#elem");
// for (let elem of arr){
//     let li = document.createElement("li");
//     li.textContent = elem;
//     li.addEventListener("click", function(){
//         li.textContent+="!"
//     }, {once:true})
//     elem_ul.appendChild(li)
// }


//466 Создание HTML таблиц
/* 
№1

Дана пустая HTML таблица. С помощью двух вложенных циклов for заполните эту таблицу 5-ю рядами с 5-ю колонками.
*/
// let table = document.querySelector('#table');

// for (let i = 0; i < 5; i++) {
// 	let tr = document.createElement('tr');
	
// 	for (let i = 0; i < 5; i++) {
// 		let td = document.createElement('td');

// 		tr.appendChild(td);
// 	}
	
// 	table.appendChild(tr);
// }

/*
№2

Модифицируйте предыдущую задачу так, чтобы таблица создавалась размером 10 рядов на 5 колонок.
*/
// let table = document.querySelector('#table');

// for (let i = 0; i < 10; i++) {
// 	let tr = document.createElement('tr');
	
// 	for (let i = 0; i < 5; i++) {
// 		let td = document.createElement('td');
// 		tr.appendChild(td);
// 	}
	
// 	table.appendChild(tr);
// }

/*
№3

Модифицируйте предыдущую задачу так, чтобы в каждую td добавлялся текст 'x'.
*/
// let table = document.querySelector('#table');

// for (let i = 0; i < 10; i++) {
// 	let tr = document.createElement('tr');
	
// 	for (let i = 0; i < 5; i++) {
// 		let td = document.createElement('td');
//         td.textContent='x';
// 		tr.appendChild(td);
// 	}
	
// 	table.appendChild(tr);
// }

/*
№4

Реализуйте генератор таблиц, ширина и высота таблиц задается в двух инпутах (например, таблица 5 на 10 ячеек).
*/
// let str_input = document.querySelector("#str");
// let kol_input = document.querySelector("#kol");
// let button = document.querySelector("#otp");
// let table = document.querySelector('#table');
// button.addEventListener("click", function(){
//     for (let i = 0; i < str_input.value; i++) {
//         let tr = document.createElement('tr');
        
//         for (let i = 0; i < kol_input.value; i++) {
//             let td = document.createElement('td');
//             td.textContent='x';
//             tr.appendChild(td);
//         }
        
//         table.appendChild(tr);
//     }
// })


//467 Последовательное заполнение HTML таблиц
/*
№1

Выведите на экран HTML таблицу размером 5 рядов на 5 колонок так, чтобы в ее ячейках последовательно стояли числа от 1 до 25.
*/
// let table = document.querySelector('#table');

// let k = 1;
// for (let i = 0; i < 5; i++) {
// 	let tr = document.createElement('tr');
	
// 	for (let i = 0; i < 5; i++) {
// 		let td = document.createElement('td');
		
// 		td.textContent = k;
// 		k++; 
		
// 		tr.appendChild(td);
// 	}
	
// 	table.appendChild(tr);
// }

/*
№2

Модифицируйте предыдущую задачу так, чтобы в ячейках таблицы были записаны четные числа в промежутке от 2 до 50.
*/
// let table = document.querySelector('#table');

// let k = 2;
// for (let i = 0; i < 5; i++) {
// 	let tr = document.createElement('tr');
	
// 	for (let i = 0; i < 5; i++) {
// 		let td = document.createElement('td');
		
// 		td.textContent = k;
// 		k+=2; 
		
// 		tr.appendChild(td);
// 	}
	
// 	table.appendChild(tr);
// }


//468 Создание HTML таблицы из массива
/*
№1

Дан массив:

let arr = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]];
Не подсматривая в теоретическую часть урока, выведите элементы приведенного массива в виде HTML таблицы table.
*/
// let arr = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]];
// let table = document.querySelector('#table');
// for (let subArr of arr){
//     let tr = document.createElement("tr");
//     for (let subSubArr of subArr){
//         let td = document.createElement("td");
//         td.textContent=subSubArr;
//         tr.appendChild(td)
//     }
//     table.appendChild(tr);
// }

/*
№2

Модифицируйте предыдущую задачу так, чтобы в таблицу записывались не элементы, а квадраты этих элементов.
*/
// let arr = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]];
// let table = document.querySelector('#table');
// for (let subArr of arr){
//     let tr = document.createElement("tr");
//     for (let subSubArr of subArr){
//         let td = document.createElement("td");
//         td.textContent=subSubArr**2;
//         tr.appendChild(td)
//     }
//     table.appendChild(tr);
// }


//469 Создание HTML таблицы из массива объектов
/*
№1

Дан следующий массив с работниками:

 
let employees = [
	{name: 'employee1', age: 30, salary: 400},
	{name: 'employee2', age: 31, salary: 500},
	{name: 'employee3', age: 32, salary: 600},
];
Выведите элементы этого массива в виде HTML таблицы.
*/
// let table = document.querySelector('#table');
// let employees = [
// 	{name: 'employee1', age: 30, salary: 400},
// 	{name: 'employee2', age: 31, salary: 500},
// 	{name: 'employee3', age: 32, salary: 600},
// ];

// for (let user of employees) {
// 	let tr = document.createElement('tr');
	
// 	let td1 = document.createElement('td');
// 	td1.textContent = user.name;
// 	tr.appendChild(td1);
	
// 	let td2 = document.createElement('td');
// 	td2.textContent = user.age;
// 	tr.appendChild(td2);
	
// 	let td3 = document.createElement('td');
// 	td3.textContent = user.salary;
// 	tr.appendChild(td3);
	
// 	table.appendChild(tr);
// }

/*
№2

Модифицируйте предыдущую задачу так, чтобы по клику на любую ячейку с возрастом ее содержимое увеличивалось на 1.
*/
// let table = document.querySelector('#table');
// let employees = [
// 	{name: 'employee1', age: 30, salary: 400},
// 	{name: 'employee2', age: 31, salary: 500},
// 	{name: 'employee3', age: 32, salary: 600},
// ];

// for (let user of employees) {
// 	let tr = document.createElement('tr');
	
// 	let td1 = document.createElement('td');
// 	td1.textContent = user.name;
// 	tr.appendChild(td1);
	
// 	let td2 = document.createElement('td');
// 	td2.textContent = user.age;
// 	tr.appendChild(td2);
// 	td2.addEventListener("click", function(){
//         td2.textContent = user.age++;
//     })

// 	let td3 = document.createElement('td');
// 	td3.textContent = user.salary;
// 	tr.appendChild(td3);
	
// 	table.appendChild(tr);
    
// }


/*
№3

Модифицируйте предыдущую задачу так, чтобы по клику на любую ячейку с зарплатой ее содержимое увеличивалось на 10%.
*/
// let table = document.querySelector('#table');
// let employees = [
// 	{name: 'employee1', age: 30, salary: 400},
// 	{name: 'employee2', age: 31, salary: 500},
// 	{name: 'employee3', age: 32, salary: 600},
// ];

// for (let user of employees) {
// 	let tr = document.createElement('tr');
	
// 	let td1 = document.createElement('td');
// 	td1.textContent = user.name;
// 	tr.appendChild(td1);
	
// 	let td2 = document.createElement('td');
// 	td2.textContent = user.age;
// 	tr.appendChild(td2);
// 	td2.addEventListener("click", function(){
//         td2.textContent = user.age++;
//     })

// 	let td3 = document.createElement('td');
// 	td3.textContent = user.salary;
// 	tr.appendChild(td3);
// 	td3.addEventListener("click", function(){
//         td3.textContent = (Number(td3.textContent)*10)/100;
//     })

// 	table.appendChild(tr);
    
// }


//470 Добавление рядов и колонок в HTML таблицу
/*
№1

Сделайте кнопку, по нажатию на которую в таблицу будет добавляться новый ряд.
*/
// let table = document.querySelector('#table');
// let button = document.querySelector("button");
// button.addEventListener("click", function(){
//     let tr = document.createElement('tr');
//     tr.textContent="item"
//     table.appendChild(tr);
// })

/*
№2

Дана таблица размером 2 на 2:

<table id="table">
	<tr>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
	</tr>
</table>
td {
	width: 50px;
	height: 50px;
	border: 1px solid black;
}
Дана также кнопка. Сделайте так, чтобы по нажатию на кнопку таблица увеличивалась на один ряд и на одну колонку.
*/
// let table2 = document.querySelector('#table2');
// let button = document.querySelector("button");
// button.addEventListener("click", function(){
// 	let trs = document.querySelectorAll('#table2 tr');
// 	let trr = document.createElement('tr');
// 	for (let tr of trs) {
// 		let td = document.createElement('td');
// 		tr.appendChild(td);
// 	}
// 	for (let i=0; i<=trs.length; i++) {
// 		let td = document.createElement('td');
// 		trr.appendChild(td);
// 	}
// 	table2.appendChild(trr);
// })


//471 Изменение ячеек HTML таблицы
/*
№1

Пусть дана некоторая HTML таблица с числами и кнопка. По нажатию на кнопку увеличьте число в каждой ячейки таблицы в два раза.
*/
// let tds = document.querySelectorAll('#table td');
// let button = document.querySelector("button");
// button.addEventListener("click", function(){
// 	for (let td of tds){
// 		td.textContent = +td.textContent*2;
// 	}
// })


//472 Самоудаление новых элементов
/*
№1 Самоудаление новых элементов

Дан следующий код:

<ul id="parent">
	<li>1</li>
	<li>2</li>
	<li>3</li>
</ul>

<input type="submit" id="button">
Сделайте так, чтобы по клику на кнопку в список добавлялся новый элемент. 
Сделайте так, чтобы любая li удалялась по клику на нее. Речь идет как о тех li, 
которые уже есть в списке, так о новых, созданных после нажатия на кнопку.
*/
// let button = document.querySelector("#button");
// let ul_par = document.querySelector("#parent");
// let i=0;
// button.addEventListener("click", function(){
// 	let li = document.createElement("li");
// 	i++;
// 	li.textContent = `newItem ${i}`;
// 	ul_par.appendChild(li);
// })
// ul_par.addEventListener("click", function(event){
// 	event.target.remove();
// })

//473 Ссылка на удаление элемента
/*
№1

Самостоятельно, не подсматривая в мой код, решите описанную задачу.
*/
// let elem   = document.querySelector('#elem');
// let remove = document.querySelector('#remove');

// remove.addEventListener('click', function(event) {
// 	elem.remove();
// 	event.preventDefault();
// });


//474 Создание ссылок для удаление элементов
/*
№1

Дан тег ul. Добавьте в конец каждого тега li ссылку на удаления этого li из списка.
*/
// let lis = document.querySelectorAll("#parent li");

// for (let li of lis) {
// 	let remove = document.createElement('a');
// 	remove.href = '';
// 	remove.textContent = 'remove';
// 	li.appendChild(remove);
	
// 	remove.addEventListener('click', function(event) {
// 		li.remove();
// 		event.preventDefault();
// 	});
// }

/*
№2

Дана HTML таблица. Добавьте в нее еще одну колонку, в которой для каждого ряда таблицы будет стоять ссылка на удаление этого ряда.
*/
// let table = document.querySelector("#table");
// let trs= document.querySelectorAll("#table tr")
// for (let tr of trs) {
// 	let td = document.createElement('td');
// 	let remove = document.createElement("a");
// 	remove.href = '';
// 	remove.textContent = "remove";
// 	tr.appendChild(td);
// 	td.appendChild(remove);
// 	remove.addEventListener('click', function(event) {
// 		tr.remove();
// 		event.preventDefault();
// 	});
// }

//475 Редактирование отдельного элемента
/*
№1

Модифицируйте приведенный выше код так, чтобы текст абзаца менялся не по потери фокуса, а по мере ввода текста в инпут.
*/
// let elem = document.querySelector('#elem');
// let input = document.querySelector('#input');

// input.value = elem.textContent;

// input.addEventListener('input', function() {
// 	elem.textContent = this.value;
// });

/*
№2

Самостоятельно, не подсматривая в мой код, решите описанную задачу.
*/
// let elem2 = document.querySelector("#parent2");
// elem2.addEventListener("click", function(){
// 	let input2= document.createElement("input");
// 	input2.value=elem2.textContent;
// 	input2.addEventListener("blur", function(){
// 		elem2.textContent=this.value;
// 		this.remove();
// 	})
// 	elem2.parentElement.appendChild(input2)
// })


//476 Прячем текст при редактировании элемента
/*
№1

Самостоятельно, не подсматривая в мой код, решите описанную задачу.
*/
// let elem2 = document.querySelector('#elem2');

// elem2.addEventListener('click', function func() {
// 	let input2 = document.createElement('input');
// 	input2.value = elem2.textContent;
// 	elem2.textContent = ''; 
// 	elem2.appendChild(input2);
// 	input2.addEventListener('blur', function() {
// 		elem2.textContent = this.value;
// 		elem2.addEventListener('click', func);
// 	});
// 	elem2.removeEventListener('click', func);
// });


//477 Редактирование в группе элементов
/*
№1

Дан тег ul. Сделайте так, чтобы по клику на любую li в ней появлялся инпут, с помощью которого можно будет поредатировать текст этой li.
*/
// let lis = document.querySelectorAll('#parent li');

// for (let li of lis) {
// 	li.addEventListener('click', function func() {
// 		let input = document.createElement('input');
// 		input.value = li.textContent;
		
// 		li.textContent = '';
// 		li.appendChild(input);
		
// 		input.addEventListener('blur', function() {
// 			li.textContent = this.value;
// 			li.addEventListener('click', func);
// 		});
		
// 		li.removeEventListener('click', func);
// 	});
// }

/*
№2

Дана HTML таблица. Сделайте так, чтобы по клику на любую ячейку в ней появлялся инпут для редактирования текста этой ячейки.
*/
// let tds = document.querySelectorAll("#table td");
// for (let td of tds){
// 	td.addEventListener("click", function func(){
// 		let input = document.createElement("input");
// 		input.value = td.textContent;
// 		td.textContent="";
// 		td.appendChild(input);
// 		input.addEventListener("blur", function(){
// 			td.textContent = this.value;
// 			td.addEventListener("click", func)
// 		})
// 		td.removeEventListener("click", func);
// 	})
// }


//478 Одновременное редактирование и удаление элементов
/*
№1

Дан следующий HTML код:

<div id="parent">
	<p><span>text1</span></p>
	<p><span>text2</span></p>
	<p><span>text3</span></p>
</div>
Добавьте ссылку на удаление в конец каждого абзаца.

Сделайте так, чтобы по клику на span в нем появлялся инпут для редактирования.
*/
// let spans = document.querySelectorAll("#parent p span");
// for (let span of spans){
// 	span.addEventListener("click", function func(){
// 		let input = document.createElement("input");
// 		let remove= document.createElement("a");
// 		remove.textContent = "remove";
// 		span.parentElement.appendChild(remove);
// 		input.value = span.textContent;
// 		span.textContent="";
// 		span.appendChild(input);
// 		input.addEventListener("blur", function(){
// 			span.textContent = this.value;
// 			span.addEventListener("click", func)
// 		})
// 		span.removeEventListener("click", func);
// 	    remove.addEventListener('click', function(event) {
// 			span.parentElement.remove();
// 			event.preventDefault();
// 	});
// 	})
// }

/*
№2

Пусть теперь изначально тегов span нет:

<div id="parent">
	<p>text1</p>
	<p>text2</p>
	<p>text3</p>
</div>
Оберните сначала текст абзаца в теги span, добавьте к этим тегам возможность редактирования, а затем добавьте в конец каждого абзаца ссылку на удаление.
*/
// let ps = document.querySelectorAll("#parent2 p");
// for(let p of ps){
// 	p.outerHTML = "<p>"+"<span>"+p.innerHTML+"</span>"+"</p>";
// }
// let spans = document.querySelectorAll("#parent2 p span")
// for (let span of spans){
// 	span.addEventListener("click", function func(){
// 		let input = document.createElement("input");
// 		let remove= document.createElement("a");
// 		remove.textContent = "remove";
// 		span.parentElement.appendChild(remove);
// 		input.value = span.textContent;
// 		span.textContent="";
// 		span.appendChild(input);
// 		input.addEventListener("blur", function(){
// 			span.textContent = this.value;
// 			span.addEventListener("click", func)
// 		})
// 		span.removeEventListener("click", func);
// 	    remove.addEventListener('click', function(event) {
// 			span.parentElement.remove();
// 			event.preventDefault();
// 	});
// 	})
// }


//479 Стилизация элементов
/* 
№1

Дан следующий HTML код:

<p>text1</p>
<p>text2</p>
<p>text3</p>
Добавьте в конец каждого абзаца ссылку, по клику на которую текст абзаца будет перечеркиваться (а ссылка - нет).
*/
// let ps = document.querySelectorAll("p");
// for (let p of ps) {
// 	p.innerHTML = '<span>' + p.innerHTML + '</span>';
// 	let link = document.createElement('a');
// 	link.href = '#';
// 	link.textContent = 'link';
// 	p.appendChild(link);
// 	let spans = document.querySelectorAll('span')
//     for (let span of spans) {
// 	link.addEventListener('click', function(event) {
// 	    span.classList.add('t-d');
// 	    event.preventDefault();
// 	})
// }
// }


/*
№2

Модифицируйте предыдущую задачу так, чтобы после нажатия на ссылку эта ссылка удалялась из абзаца (а текст абзаца становился перечеркнутым).
*/
// let ps = document.querySelectorAll("p");
// for (let p of ps) {
// 	p.innerHTML = '<span>' + p.innerHTML + '</span>';
// 	let link = document.createElement('a');
// 	link.href = '#';
// 	link.textContent = 'link';
// 	p.appendChild(link);
// 	let spans = document.querySelectorAll('span')
//     for (let span of spans) {
// 	link.addEventListener('click', function(event) {
// 	    span.classList.add('t-d');
// 	    event.preventDefault();
// 		link.remove()
// 	})
// }
// }

/*
№3

Дана некоторая HTML таблица. Добавьте в эту таблицу еще одну колонку со ссылкой. По нажатию на эту ссылку ряд с этой ссылкой должен стать зеленого фона.
*/
// let table = document.querySelector("#table");
// let trs= document.querySelectorAll("#table tr")
// for (let tr of trs) {
// 	let td = document.createElement('td');
// 	let background = document.createElement("a");
// 	background.href = '';
// 	background.textContent = "background green";
// 	tr.appendChild(td);
// 	td.appendChild(background);
// 	background.addEventListener('click', function(event) {
// 		tr.classList.add("fon-green");
// 		event.preventDefault();
// 	});
// }

/*
№4

Модифицируйте предыдущую задачу так, чтобы первое нажатие по ссылке красило ряд в зеленый фон, а второе нажатие отменяло это действие.
*/
// let table = document.querySelector("#table");
// let trs= document.querySelectorAll("#table tr")
// for (let tr of trs) {
// 	let td = document.createElement('td');
// 	let background = document.createElement("a");
// 	background.href = '';
// 	background.textContent = "background green";
// 	tr.appendChild(td);
// 	td.appendChild(background);
// 	background.addEventListener('click', function(event) {
// 		tr.classList.toggle("fon-green");
// 		event.preventDefault();
// 	});
// }


//480 Кнопки для скрытия и показа элемента
/*
№1

Модифицируйте мой код так, чтобы была только одна кнопка. Пусть по первому клику на эту кнопку элемент показывается, а по второму - скрывается.
*/
// let elem = document.querySelector('#elem');
// let hide = document.querySelector('#hide');
// hide.addEventListener('click', function() {
// 	elem.classList.toggle('hidden');
// });


//481 Много элементов с кнопками показа
/*
№1

Изучите мое решение, а затем самостоятельно, не подсматривая в мой код, решите эту задачу.
*/
// let buttons = document.querySelectorAll('button');

// for (let button of buttons) {
// 	button.addEventListener('click', function() {
// 		let elem = document.querySelector('#' + this.dataset.elem);
// 		elem.classList.toggle('hidden');
// 	});
// }

/*
№2

Изучите мое решение, а затем самостоятельно, не подсматривая в мой код, решите эту задачу.
*/
// let buttons = document.querySelectorAll('button');
// let elems   = document.querySelectorAll('p');

// for (let i = 0; i < buttons.length; i++) {
// 	buttons[i].addEventListener('click', function() {
// 		elems[i].classList.toggle('hidden');
// 	});
// }

/*
№3

Изучите мое решение, а затем самостоятельно, не подсматривая в мой код, решите эту задачу.
*/
// let buttons = document.querySelectorAll('button');

// for (let button of buttons) {
// 	button.addEventListener('click', function() {
// 		this.previousElementSibling.classList.toggle('hidden');
// 	});
// }

//482 Активация элементов
/*
№1

Дана HTML список ul. Сделайте так, чтобы по нажатию на любой пункт списка он активировался красным фоном.
*/
// let lis = document.querySelectorAll("#elem li");
// for(let li of lis){
// 	li.addEventListener("click", function(){
// 		this.classList.add("active");
// 	})
// }

/*
№2

Модифицируйте предыдущую задачу так, чтобы по нажатию на активированный пункт списка активация с него снималась.
*/
// let lis = document.querySelectorAll("#elem li");
// for(let li of lis){
// 	li.addEventListener("click", function(){
// 		this.classList.toggle("active");
// 	})
// }

//483 Чередование стилей активации
/*
№1

Разберите мой код, а затем самостоятельно повторите решение этой задачи.
*/
// let tds = document.querySelectorAll('#table td');

// let color = 'color1';
// for (let td of tds) {
// 	td.addEventListener('click', function() {
// 		if (color == 'color1') {
// 			color = 'color2'
// 		} else {
// 			color = 'color1'
// 		}
		
// 		this.classList.add(color);
// 	});
// }

//484 Практика на изменение элементов
/*
№1

Дан массив. Выведите его элементы в виде списка ul.
*/
// let arr = [1, 2, 3, 4, 5];
// let elem_ul=document.querySelector("#elem");
// for (let elem of arr){
//     let li = document.createElement("li");
//     li.textContent = elem;
//     elem_ul.appendChild(li)
// }

/*
№2

Модифицируйте предыдущую задачу так, чтобы по клику на любую li в ней появлялся инпут, с помощью которого ее можно будет поредактировать.
*/
// let lis = document.querySelectorAll('#parent li');

// for (let li of lis) {
// 	li.addEventListener('click', function func() {
// 		let input = document.createElement('input');
// 		input.value = li.textContent;
		
// 		li.textContent = '';
// 		li.appendChild(input);
		
// 		input.addEventListener('blur', function() {
// 			li.textContent = this.value;
// 			li.addEventListener('click', func);
// 		});
		
// 		li.removeEventListener('click', func);
// 	});
// }

/*
№3

Модифицируйте предыдущую задачу так, чтобы под списком был инпут, с помощью которого можно будет добавить новый элемент в конец списка ul. 
Сделайте так, чтобы новые li также можно было редактировать.
*/
// let button = document.querySelector("#button");
// let ul_par = document.querySelector("#parent");
// let i=0;
// button.addEventListener("click", function(){
// 	let li = document.createElement("li");
// 	i++;
// 	li.textContent = `newItem ${i}`;
// 	ul_par.appendChild(li);
// })
// ul_par.addEventListener('click', function func(event) {
// 	let input = document.createElement('input');
// 	input.value = event.target.textContent;
// 	event.target.textContent = '';
// 	event.target.appendChild(input);	
// 	input.addEventListener('blur', function() {
// 		event.target.textContent = this.value;
// 		event.target.addEventListener('click', func);
// 	});
		
// 		event.target.removeEventListener('click', func);
// });

/*
№4

Модифицируйте предыдущую задачу так, чтобы в конце каждой li стояла ссылка 'удалить', с помощью которой можно будет удалить эту li из ul.
*/

// let parent =document.querySelector("#parent")
// let lis=document.querySelectorAll("#parent li")
// for(let li of lis){
// 	li.outerHTML = "<li>"+"<span>"+li.innerHTML+"</span>"+"</li>";
// }
// let spans = document.querySelectorAll("#parent li span")
// function zadach(span){
// 	span.addEventListener("click", function func(){
// 		let input = document.createElement("input");
// 		input.value = span.textContent;
// 		span.textContent="";
// 		span.appendChild(input);
// 		input.focus();
// 		input.addEventListener("blur", function(){
// 			span.textContent = this.value;
// 			span.addEventListener("click", func);
// 		})
// 	    span.removeEventListener("click", func);
// 	})
// }
// function zadachRem(span){
// 	let remove= document.createElement("a");
// 	remove.textContent = "remove";
// 	span.parentElement.appendChild(remove);
// 	remove.addEventListener('click', function(event) {
// 		span.parentElement.remove();
// 		event.preventDefault();
//     });
// }
// for (let span of spans){
// 	zadach(span);
// 	zadachRem(span);
// }

// const but2 = document.querySelector("#button")
// but2.addEventListener('click', function (event) {
// 	let li = document.createElement('li');
// 	let span = document.createElement("span");
// 	span.textContent = "new element";
// 	li.append(span);
// 	parent.append(li);
// 	zadach(li.firstElementChild);
// 	zadachRem(li.firstElementChild)
// })


/*
№5

Модифицируйте предыдущую задачу так, чтобы в конце каждой li также стояла ссылка 'перечеркнуть', с помощью которой можно будет перечеркнуть текст данного тега li.
*/
// let parent =document.querySelector("#parent")
// let lis=document.querySelectorAll("#parent li")
// for(let li of lis){
// 	li.outerHTML = "<li>"+"<span>"+li.innerHTML+"</span>"+"</li>";
// }
// let spans = document.querySelectorAll("#parent li span")
// function zadach(span){
// 	span.addEventListener("click", function func(){
// 		let input = document.createElement("input");
// 		input.value = span.textContent;
// 		span.textContent="";
// 		span.appendChild(input);
// 		input.focus();
// 		input.addEventListener("blur", function(){
// 			span.textContent = this.value;
// 			span.addEventListener("click", func);
// 		})
// 	    span.removeEventListener("click", func);
// 	})
// }
// function zadachPerecherk(span){
// 	let link = document.createElement('a');
// 	link.href = '#';
// 	link.textContent = 'link';
// 	span.parentElement.appendChild(link);
// 	link.addEventListener('click', function(event) {
// 	    span.classList.toggle('t-d');
// 	    event.preventDefault();
// 	})
// }
// function zadachRem(span){
// 	let remove= document.createElement("a");
// 	remove.textContent = "remove";
// 	span.parentElement.appendChild(remove);
// 	remove.addEventListener('click', function(event) {
// 		span.parentElement.remove();
// 		event.preventDefault();
//     });
// }
// for (let span of spans){
// 	zadach(span);
// 	zadachRem(span);
// 	zadachPerecherk(span);
// }

// const but2 = document.querySelector("#button")
// but2.addEventListener('click', function (event) {
// 	let li = document.createElement('li');
// 	let span = document.createElement("span");
// 	span.textContent = "new element";
// 	li.append(span);
// 	parent.append(li);
// 	zadach(li.firstElementChild);
// 	zadachRem(li.firstElementChild);
// 	zadachPerecherk(li.firstElementChild)
// })


/*
№6

Дан следующий массив с работниками:

let employees = [
	{name: 'employee1', age: 30, salary: 400},
	{name: 'employee2', age: 31, salary: 500},
	{name: 'employee3', age: 32, salary: 600},
];
Выведите этих работников в HTML таблице.
*/
// let employees = [
// 	{name: 'employee1', age: 30, salary: 400},
// 	{name: 'employee2', age: 31, salary: 500},
// 	{name: 'employee3', age: 32, salary: 600},
// ];

// let table = document.querySelector('#table');

// for (let user of employees) {
// 	let tr = document.createElement('tr');
	
// 	let td1 = document.createElement('td');
// 	td1.textContent = user.name;
// 	tr.appendChild(td1);
	
// 	let td2 = document.createElement('td');
// 	td2.textContent = user.age;
// 	tr.appendChild(td2);
	
// 	let td3 = document.createElement('td');
// 	td3.textContent = user.salary;
// 	tr.appendChild(td3);
	
// 	table.appendChild(tr);
// }


/*
№7

Добавьте ячейкам созданной таблицы возможность редактирования.
*/
// let table = document.querySelector('#table');
// let tds = document.querySelectorAll("#table td")
// for (let td of tds){
// 	td.addEventListener("click", function func(){
// 	  let input = document.createElement("input");
// 		input.value = td.textContent;
// 		td.textContent="";
// 		td.appendChild(input);
// 		input.focus();
// 		input.addEventListener("blur", function(){
// 			td.textContent = this.value;
// 			td.addEventListener("click", func);
// 		})
// 		td.removeEventListener("click", func);
// })}

/*
№8

Добавьте в вашу таблицу новую колонку со ссылкой на удаления ряда из таблицы.
*/
// let table = document.querySelector('#table');
// let trs = document.querySelectorAll("#table tr")
// let tds = document.querySelectorAll("#table td")
// for (let td of tds){
// 	td.addEventListener("click", function func(){
// 	    let input = document.createElement("input");
// 		input.value = td.textContent;
// 		td.textContent="";
// 		td.appendChild(input);
// 		input.focus();
// 		input.addEventListener("blur", function(){
// 			td.textContent = this.value;
// 			td.addEventListener("click", func);
// 		})
// 		td.removeEventListener("click", func);
//     })
// }
// for(let tr of trs){
// 	let remove= document.createElement("a");
// 	remove.textContent = "remove";
// 	tr.appendChild(remove);
// 	remove.addEventListener('click', function(event) {
// 		tr.remove();
// 		event.preventDefault();
//     });
// }

/*
№9

Сделайте под таблицей 3 инпута и кнопку для добавление нового работника. Пусть в инпуты вводятся имя, возраст и зарплата, 
и по нажатию на кнопку новый работник добавляется в таблицу. Реализуйте редактирование ячеек для вновь добавленных работников.
*/
// let inputName = document.querySelector('#nameInput');
// let inputAge = document.querySelector('#ageInput');
// let inputSalary = document.querySelector('#salaryInput');
// let addButton = document.querySelector('#addButton');
// let table = document.querySelector("#workersTable");
// let body = document.querySelector("body")
// function red(td){
// 	td.addEventListener("click", function func(){
// 	  let input = document.createElement("input");
// 		input.value = td.textContent;
// 		td.textContent="";
// 		td.appendChild(input);
// 		input.focus();
// 		input.addEventListener("blur", function(){
// 			td.textContent = this.value;
// 			td.addEventListener("click", func);
// 		})
//   		td.removeEventListener("click", func);
// })}
// addButton.addEventListener('click', function() {
//   let name = inputName.value;
//   let age = inputAge.value;
//   let salary = inputSalary.value;

// 	let tr = document.createElement('tr');

// 	let tdName = document.createElement('td');
// 	tdName.textContent = name;
// 	tr.appendChild(tdName);
//   red(tdName);

// 	let tdAge = document.createElement('td');
// 	tdAge.textContent = age;
// 	tr.appendChild(tdAge);
//   red(tdAge);

// 	let tdSalary = document.createElement('td');
// 	tdSalary.textContent = salary;
// 	tr.appendChild(tdSalary);
//   red(tdSalary);

// 	let tdRemove = document.createElement('td');
// 	let remove = document.createElement('a');
// 	remove.textContent = ' remove';
// 	remove.onclick = () => {
// 		table.removeChild(tr);
// 	}
// 	tdRemove.appendChild(remove);
// 	tr.appendChild(tdRemove);

// 	table.appendChild(tr);

// 	inputName.value = '';
// 	inputAge.value = '';
// 	inputSalary.value = '';
// });

// body.appendChild(inputName);
// body.appendChild(inputAge);
// body.appendChild(inputSalary);
// body.appendChild(addButton);



/*
№10

Дан следующий массив с работниками:

let employees = [
	{name: 'employee1', age: 30, salary: 400},
	{name: 'employee2', age: 31, salary: 500},
	{name: 'employee3', age: 32, salary: 600},
];
Выведите на экран каждого работника в своем теге li тега ul.
*/
// let employees = [
// 	{name: 'employee1', age: 30, salary: 400},
// 	{name: 'employee2', age: 31, salary: 500},
// 	{name: 'employee3', age: 32, salary: 600},
// ];
// let ul = document.querySelector("#elem");
// for (let user of employees) {
// 	let li1 = document.createElement('li');
// 	li1.textContent = user.name;
// 	ul.appendChild(li1);
// }

/*
№11

Сделайте так, чтобы по клику на имя, возраст или зарплату работника появлялся инпут для редактирования этого поля.
*/
// let employees = [
// 	{name: 'employee1', age: 30, salary: 400},
// 	{name: 'employee2', age: 31, salary: 500},
// 	{name: 'employee3', age: 32, salary: 600},
// ];
// function red(li){
//   li.addEventListener("click", function func(){
//     let input = document.createElement("input");
//     input.value = li.textContent;
//     li.textContent="";
//     li.appendChild(input);
//     input.focus();
//     input.addEventListener("blur", function(){
//     	li.textContent = this.value;
//     	li.addEventListener("click", func);
//     })
//       li.removeEventListener("click", func);
//     })
// }
// for (let user of employees) {
//   let ul = document.querySelector("#elem");
// 	let li1 = document.createElement('li');
// 	li1.textContent = user.name;
// 	ul.appendChild(li1);
//   red(li1);

// 	let li2 = document.createElement('li');
// 	li2.textContent = user.age;
// 	ul.appendChild(li2);
//   red(li2);

//   let li3 = document.createElement('li');
// 	li3.textContent = user.salary;
// 	ul.appendChild(li3);
//   red(li3);
// }


/*
№12

Добавьте в конец каждого тега li ссылку на удаление этого li из списка.
*/
// let employees = [
// 	{name: 'employee1', age: 30, salary: 400},
// 	{name: 'employee2', age: 31, salary: 500},
// 	{name: 'employee3', age: 32, salary: 600},
// ];
// let ul = document.querySelector("#elem");

// for (let user of employees) {
// 	let li = document.createElement('li');
// 	li.innerHTML =`<span> ${user.name} ${user.age} ${user.salary} </span>`;
// 	ul.appendChild(li);
//   let remove = document.createElement('a');
// 	remove.textContent = ' remove';
// 	remove.onclick = () => {
// 		li.remove();
// 	}
// 	li.appendChild(remove);
// }
// let spans=document.querySelectorAll("#elem li span");
// for (let span of spans){
//   	span.addEventListener("click", function func(){
// 		let input = document.createElement("input");
// 		input.value = span.textContent;
// 		span.textContent="";
// 		span.appendChild(input);
// 		input.focus();
// 		input.addEventListener("blur", function(){
// 			span.textContent = this.value;
// 			span.addEventListener("click", func);
// 		})
// 	    span.removeEventListener("click", func);
// 	})
// }


/*
№13

Под списком сделайте форму для добавления нового работника.
*/
// let employees = [
// 	{name: 'employee1', age: 30, salary: 400},
// 	{name: 'employee2', age: 31, salary: 500},
// 	{name: 'employee3', age: 32, salary: 600},
// ];
// let ul = document.querySelector("#elem");
// function rem(li){
//   let remove = document.createElement('a');
// 	remove.textContent = ' remove';
// 	remove.onclick = () => {
// 		li.remove();
// 	}
// 	li.appendChild(remove);
// }
// function red(span){
//   span.addEventListener("click", function func(){
// 		let input = document.createElement("input");
// 		input.value = span.textContent;
// 		span.textContent="";
// 		span.appendChild(input);
// 		input.focus();
// 		input.addEventListener("blur", function(){
// 			span.textContent = this.value;
// 			span.addEventListener("click", func);
// 		})
// 	    span.removeEventListener("click", func);
// 	})
// }
// for (let user of employees) {
// 	let li = document.createElement('li');
// 	li.innerHTML =`<span> ${user.name} ${user.age} ${user.salary} </span>`;
// 	ul.appendChild(li);
//   rem(li);
// }
// let spans=document.querySelectorAll("#elem li span");
// for (let span of spans){
//   	red(span);
// }

// const but2 = document.querySelector("#button")
// but2.addEventListener('click', function (event) {
// 	let li = document.createElement('li');
// 	let span = document.createElement("span");
// 	span.textContent = "new element";
// 	li.append(span);
// 	ul.append(li);
//   rem(li)
//   red(span)
// })